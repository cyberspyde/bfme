#include "other.h"
#include <windows.h>

void other() {
    MessageBoxA(NULL, "Other functionality is under development.", "Other", MB_OK | MB_ICONINFORMATION);
}