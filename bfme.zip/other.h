#ifndef OTHER_H
#define OTHER_H

#include <windows.h>

// Function to handle the "Other" button functionality
void other();

#endif // OTHER_H