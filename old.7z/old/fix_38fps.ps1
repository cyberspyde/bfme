FPS_FIXER_PATCH = "https://drive.google.com/uc?export=download&id=1tUYSiCQj23QawpaG8DOT1HpQ-w4ABdcV"
FPS_FIXER_CLIENT = "https://drive.google.com/uc?export=download&id=1ta40-91YDXV4b7rNLYhvR9TrS2gDAhw6"
